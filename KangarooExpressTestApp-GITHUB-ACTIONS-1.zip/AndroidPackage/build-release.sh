#!/bin/sh
./gradlew assembleRelease
