#!/bin/sh
./gradlew assembleDebug
